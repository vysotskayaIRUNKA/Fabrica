import pandas as pd

df = pd.read_csv('transactions.csv')

ok = df[df['STATUS'] == 'OK']

print("Топ-3 платежа (OK):")
print(ok.nlargest(3, 'SUM')[['CONTRACTOR', 'SUM']].to_string(index=False))

total = ok[ok['CONTRACTOR'] == 'Umbrella, Inc']['SUM'].sum()
print(f"\nСумма платежей в адрес Umbrella, Inc (OK): {total}")