import pandas as pd
import matplotlib.pyplot as plt

students = pd.read_excel('students_info.xlsx', sheet_name='logins')
students = students.dropna(subset=['login'])

tables = pd.read_html('results_ejudge.html')
results = tables[0][['User', 'G', 'H']]
results.columns = ['login', 'G', 'H']

def to_num(x):
    try:
        return float(x)
    except (ValueError, TypeError):
        return 0.0

results['G'] = results['G'].apply(to_num)
results['H'] = results['H'].apply(to_num)

merged = students.merge(results, on='login', how='left')
merged['G'] = merged['G'].fillna(0)
merged['H'] = merged['H'].fillna(0)
merged['solved'] = merged['G'] + merged['H']

by_faculty = merged.groupby('group_faculty')['solved'].mean()
by_out = merged.groupby('group_out')['solved'].mean()

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

axes[0].bar(by_faculty.index.astype(str), by_faculty.values, color='steelblue')
axes[0].set_title('Средний балл (G+H) по факультетским группам')
axes[0].set_xlabel('Факультетская группа')
axes[0].set_ylabel('Средний балл')

axes[1].bar(by_out.index.astype(str), by_out.values, color='seagreen')
axes[1].set_title('Средний балл (G+H) по группам информатики')
axes[1].set_xlabel('Группа по информатике')
axes[1].set_ylabel('Средний балл')

plt.tight_layout()
plt.savefig('avg_scores.png', dpi=150)
plt.show()

target = merged[(merged['G'] >= 20) | (merged['H'] >= 20)]

with open('task2_result.txt', 'w', encoding='utf-8') as f:
    f.write("Логины, прошедшие >1 теста в G или H:\n")
    f.write(target[['login', 'group_faculty', 'group_out', 'G', 'H']].to_string(index=False))
    f.write("\n\nФакультетские группы:\n")
    f.write(str(sorted(target['group_faculty'].unique().tolist())))
    f.write("\n\nГруппы по информатике:\n")
    f.write(str(sorted(target['group_out'].unique().tolist())))
    f.write("\n")