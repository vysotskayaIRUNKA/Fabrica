import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('flights.csv')

stats = df.groupby('CARGO').agg(
    flights=('PRICE', 'count'),
    total_price=('PRICE', 'sum'),
    total_weight=('WEIGHT', 'sum')
).reset_index()

print(stats.to_string(index=False))



fig, axes = plt.subplots(1, 3, figsize=(15, 4))

axes[0].bar(stats['CARGO'], stats['flights'], color='steelblue')
axes[0].set_title('Количество рейсов')
axes[0].set_xlabel('Авиакомпания')
axes[0].set_ylabel('Рейсов')

axes[1].bar(stats['CARGO'], stats['total_price'], color='seagreen')
axes[1].set_title('Суммарная стоимость грузов')
axes[1].set_xlabel('Авиакомпания')
axes[1].set_ylabel('Стоимость')

axes[2].bar(stats['CARGO'], stats['total_weight'], color='darkorange')
axes[2].set_title('Суммарная масса грузов')
axes[2].set_xlabel('Авиакомпания')
axes[2].set_ylabel('Масса')

plt.tight_layout()
plt.savefig('flights_stats.png', dpi=150)
plt.show()